<?php
$this->load->view('part/header.php');
$this->load->view($page);
$this->load->view('part/footer.php');
 ?>
